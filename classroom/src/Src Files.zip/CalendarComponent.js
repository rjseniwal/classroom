import { Calendar, momentLocalizer } from "react-big-calendar";
import React, { useState, useEffect } from "react";
import "react-big-calendar/lib/css/react-big-calendar.css";
import moment from "moment";
import db from "./firebase";
import { useStateValue } from "./StateProvider";
const localizer = momentLocalizer(moment);

function CalendarComponent(props) {
	let date = new Date();
	// add a day
	date.setDate(date.getDate() + 1);
	const [{ user }, dispatch] = useStateValue();
	const [myEventsList, setmyEventsList] = useState([
		// {
		// 	title: "Neural Networks",
		// 	start: new Date(2020, 11, 4, 10, 0), // 10.00 AM
		// 	end: new Date(2020, 11, 4, 11, 0), // 2.00 PM
		// },
		// {
		// 	title: "Maths",
		// 	start: new Date(2020, 11, 4, 9, 0), // 10.00 AM
		// 	end: new Date(2020, 11, 4, 1, 0), // 2.00 PM
		// },
		// {
		// 	title: "Neural Networks Project",
		// 	start: new Date(2020, 11, 2, 8, 0), // 10.00 AM
		// 	end: new Date(2020, 11, 2, 12, 0), // 2.00 PM
		// },
		// {
		// 	title: "English",
		// 	start: new Date(2020, 11, 5, 7, 0), // 10.00 AM
		// 	end: new Date(2020, 11, 5, 8, 0), // 2.00 PM
		// },
	]);
	useEffect(() => {
		db.collection("Users")
			.where("email", "==", user.email)
			.get()
			.then((snapshot) => {
				snapshot.forEach((doca) => {
					console.log(doca.id);
					db.collection("Users")
						.doc(doca.id)
						.collection("ClassesEnrolled")
						.onSnapshot((snap) => {
							snap.forEach((docb) => {
								console.log("classId : ", docb.data().classId);
								db.collection("Classes")
									.doc(docb.data().classId)
									.collection("Events")
									.onSnapshot((ss) => {
										ss.forEach((ssi) => {
											setmyEventsList((myEventsList) => [
												...myEventsList,
												{
													title: ssi.data().title,
													start: ssi.data().endTimeStamp.toDate(),
													end: ssi.data().endTimeStamp.toDate(),
												},
											]);
											// console.log(
											// 	ssi.data().startTimeStamp.toDate().getMonth()
											// );
										});
									});
							});
						});
					// setIsTeacher(doca.data().isTeacher);
				});
			});
		// setmyEventsList([
		// 	{
		// 		title: "Neural Networks",
		// 		start: new Date(2020, 11, 4, 10, 0), // 10.00 AM
		// 		end: new Date(2020, 11, 4, 11, 0), // 2.00 PM
		// 	},
		// ]);
	}, []);

	useEffect(() => {
		console.log(myEventsList);
	});
	return (
		<Calendar
			localizer={localizer}
			events={myEventsList}
			startAccessor="start"
			endAccessor="end"
			view="week"
			views={["week", "day"]}
		/>
	);
}
export default CalendarComponent;
