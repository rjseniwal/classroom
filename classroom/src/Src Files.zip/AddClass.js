import React, { useState, useEffect } from "react";
import DateTimePicker from "react-datetime-picker";
import "./AddClass.css";
import db from "./firebase";
import { useParams } from "react-router-dom";
import { useHistory } from "react-router-dom";

function AddClass() {
	const [addButtonClicked, setAddButton] = useState(false);
	const [classChosen, setClassChosen] = useState(false);
	const [isExtra, setIsExtra] = useState(false);
	const [classStartTime, setStartTime] = useState(new Date());
	const [classEndTime, setEndTime] = useState(new Date());
	const [classTitle, setTitle] = useState("");
	const history = useHistory();

	const { classId } = useParams();

	const addToDb = (title, start, end) => {
		db.collection("Classes").doc(classId).collection("Events").add({
			title: title,
			startTimeStamp: start,
			endTimeStamp: end,
		});
	};

	const addNewClass = () => {
		// e.preventDefault();

		addToDb(classTitle, classStartTime, classEndTime);

		if (isExtra == false) {
			var i = 0;
			var newStart = new Date(classStartTime);
			var newEnd = new Date(classEndTime);
			for (i = 0; i < 27; i++) {
				newStart.setDate(newStart.getDate() + 7);
				newEnd.setDate(newEnd.getDate() + 7);
				// console.log(newStart);
				addToDb(classTitle, newStart, newEnd);
			}
			// console.log(newStart);
		}
		alert("Your new class has been added");
		history.replace(`/class/${classId}`);
	};

	return (
		<div className="addclass">
			<div className="addclass-container">
				{/* <button onClick={() => setAddButton(true)}>ADD A NEW CLASS</button> */}
				<div>
					{/* {addButtonClicked ? ( */}
					<div className="button-container">
						<button
							onClick={() => {
								setClassChosen(true);
								setIsExtra(false);
							}}
						>
							Regular Class
						</button>
						<button
							onClick={() => {
								setClassChosen(true);
								setIsExtra(true);
							}}
						>
							Extra Class
						</button>
					</div>
					{/* ) : null} */}
				</div>
				{classChosen ? (
					<div className="add-class-inputs">
						<div className="add-class-labels">
							<label>Class Name:</label>
							<label>Class Start Time:</label>
							<label>Class End Time:</label>
						</div>
						<div className="add-class-values">
							<input
								className="add-class-input"
								type="text"
								value={classTitle}
								onChange={(e) => setTitle(e.target.value)}
							></input>
							<DateTimePicker
								// className="add-class-input"
								onChange={setStartTime}
								value={classStartTime}
							/>
							<DateTimePicker
								// className="add-class-input"
								onChange={setEndTime}
								value={classEndTime}
							/>
						</div>
						<button onClick={addNewClass} type="submit">
							Submit
						</button>
					</div>
				) : null}
			</div>
		</div>
	);
}

export default AddClass;
